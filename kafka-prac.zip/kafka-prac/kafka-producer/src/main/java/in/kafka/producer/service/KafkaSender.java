package in.kafka.producer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import in.kafka.producer.model.Employee;

@Service
public class KafkaSender {
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	@Autowired
	private KafkaTemplate<String, Employee> employeeKafkaTemplate;
	
	String kafkaTopic1 = "testapp";
	String kafkaTopic2 = "testapp-2";
	
	public void send(String message) {
	    
	    kafkaTemplate.send(kafkaTopic1, message);
	}
	
	public void sendEmployee(Employee employee) {
	    
		employeeKafkaTemplate.send(kafkaTopic2, employee);
	}
}